package com.quinbay.march22.SpringApplication2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringApplication2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
