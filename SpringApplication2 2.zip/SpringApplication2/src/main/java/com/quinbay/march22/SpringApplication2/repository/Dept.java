//package com.quinbay.march22.SpringApplication2.repository;
//
//import com.quinbay.march22.SpringApplication2.dto.Student;
//
//import java.util.ArrayList;
//import java.util.List;
//
//public class Dept {
//
//    public String dname;
//    public String pname;
//
//    public Dept(String dname, String pname, int did) {
//        this.dname = dname;
//        this.pname = pname;
//        this.did = did;
//    }
//
//    public String getDname() {
//
//        return dname;
//    }
//
//    public void setDname(String dname) {
//        this.dname = dname;
//    }
//
//    public String getPname() {
//        return pname;
//    }
//
//    public void setPname(String pname) {
//        this.pname = pname;
//    }
//
//    public int getDid() {
//        return did;
//    }
//
//    public void setDid(int did) {
//        this.did = did;
//    }
//
//    public int did;
//
//
//
//}
